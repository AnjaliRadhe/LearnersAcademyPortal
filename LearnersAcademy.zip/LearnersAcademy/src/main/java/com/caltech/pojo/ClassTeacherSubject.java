package com.caltech.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ClassTeacherSubject {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int ctsid;
	private String clname;
	private String tename;
	private String subname;

	public int getCtsid() {
		return ctsid;
	}

	public void setCtsid(int ctsid) {
		this.ctsid = ctsid;
	}

	public String getClname() {
		return clname;
	}

	public void setClname(String clname) {
		this.clname = clname;
	}

	public String getTename() {
		return tename;
	}

	public void setTename(String tename) {
		this.tename = tename;
	}

	public String getSubname() {
		return subname;
	}

	public void setSubname(String subname) {
		this.subname = subname;
	}

	@Override
	public String toString() {
		return "ClassTeacherSubject [ctsid=" + ctsid + ", clname=" + clname + ", tename=" + tename + ", subname="
				+ subname + "]";
	}

}
