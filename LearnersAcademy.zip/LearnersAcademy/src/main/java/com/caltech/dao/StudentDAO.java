package com.caltech.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.caltech.dbconfig.DbUtil;
import com.caltech.pojo.ClassTeacherSubject;
import com.caltech.pojo.Classes;
import com.caltech.pojo.Student;
import com.caltech.pojo.Subjects;
import com.caltech.pojo.Teacher;


public class StudentDAO {
	public List<Student> display() throws ClassNotFoundException, SQLException {
		DbUtil dbutil = new DbUtil();
		Session session = dbutil.dbConn();
		System.out.println(session);
		Transaction tran = session.beginTransaction();
		System.out.println(tran);
		if (session != null)
			System.out.println("db configurations are done");
		else
			System.out.println("connection with db failed");

		Query q = session.createQuery("from Student");
		List<Student> list = q.list();
		return list;
	}
	public int addstudent(Student stu) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {
			Student cl = new Student();
			cl.setSname(stu.getSname());	
			cl.setClasses(stu.getClasses());
			value = (Integer) session.save(cl);
			System.out.println(value);
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}
	public int editstudent(Student stu) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {
			Query q = session.createQuery("update Student set sname=:name,cid=:cid where sid=:id");
			Student t1 = new Student();
			t1.setSname(stu.getSname());
			t1.setClasses(stu.getClasses());
			t1.setSid(stu.getSid());
			q.setParameter("name", t1.getSname());
			q.setParameter("cid", t1.getClasses().getCid());
			q.setParameter("id", t1.getSid());
			value = q.executeUpdate();
			if (value > 0) {
				System.out.println("updated");
			}
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}
	public int deletestudent(Student stu) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {

			Query q = session.createQuery("delete from Student where sid=:id");
			Student t1 = new Student();
			t1.setSid(stu.getSid());
			q.setParameter("id", t1.getSid());
			value = q.executeUpdate();
			System.out.println(value);
			if (value > 0) {
				System.out.println("deleted");
			}
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}
	public List<Student> getstudentsforcourse(Classes classes) throws ClassNotFoundException, SQLException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		List<Student> list;
		try {
			Classes cl=new Classes();
			cl.setCid(classes.getCid());
			Query q = session.createQuery("from Student where cid=:id");
			Student t1 = new Student();
			t1.setClasses(cl);
			q.setParameter("id", t1.getClasses().getCid());
			list = q.list();
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			list = null;
		}
		
		return list;
	}
}
