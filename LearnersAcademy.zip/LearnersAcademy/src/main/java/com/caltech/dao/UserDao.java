package com.caltech.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.io.IOException;

import com.caltech.dbconfig.DbUtil;
import com.caltech.pojo.User;

public class UserDao {

	public String adduser(User user) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		String value = null;
		try {
			User newuser = new User();
			newuser.setUser(user.getUser());
			newuser.setPassword(user.getPassword());
			value = (String) session.save(newuser);
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = null;
		}
		return value;
	}

	public String validateuser(User user) {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		// better to use HQL
		User newuser = session.get(User.class, user.getUser());
		trans.commit();
		session.close();
		if (newuser != null) {
			if ((newuser.getUser().equals(user.getUser())) && (newuser.getPassword().equals(user.getPassword()))) {
				String value = "succeess";
				return value;
			} else {
				String value = null;
				return value;
			}
		}
		String value = null;
		return value;
	}

}
