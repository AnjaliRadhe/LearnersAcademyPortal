package com.caltech.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.caltech.dbconfig.DbUtil;
import com.caltech.pojo.Classes;
import com.caltech.pojo.Teacher;

public class TeacherDAO {

	public List<Teacher> display() throws ClassNotFoundException, SQLException {
		DbUtil dbutil = new DbUtil();
		Session session = dbutil.dbConn();
		System.out.println(session);
		Transaction tran = session.beginTransaction();
		System.out.println(tran);
		if (session != null)
			System.out.println("db configurations are done");
		else
			System.out.println("connection with db failed");

		Query q = session.createQuery("from Teacher");
		List<Teacher> list = q.list();
		return list;
	}

	public int addteacher(Teacher teacher) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {
			Teacher t1 = new Teacher();
			t1.setTname(teacher.getTname());
			value = (Integer) session.save(t1);
			System.out.println(value);
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}

	public int editteacher(Teacher teacher) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {

			Query q = session.createQuery("update Teacher set tname=:name where tid=:id");
			Teacher t1 = new Teacher();
			t1.setTid(teacher.getTid());
			t1.setTname(teacher.getTname());
			q.setParameter("name", t1.getTname());
			q.setParameter("id", t1.getTid());
			value = q.executeUpdate();
			if (value > 0) {
				System.out.println("updated");
			}
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}

	public int deleteteacher(Teacher teacher) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {

			Query q = session.createQuery("delete from Teacher where tid=:id");
			Teacher t1 = new Teacher();
			t1.setTid(teacher.getTid());
			q.setParameter("id", t1.getTid());
			value = q.executeUpdate();
			// System.out.println(value);
			if (value > 0) {
				System.out.println("deleted");
			}
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}

	public List<Teacher> teacherdropdownpopulate(Teacher teacher)throws ClassNotFoundException, SQLException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		List<Teacher> list= new ArrayList<Teacher>();
		try
		{
		Query q = session.createQuery("from Teacher");
		 list= q.list();
		trans.commit();
		session.close();
		}catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while retrieving values");
		}
		return list;
	}
}
