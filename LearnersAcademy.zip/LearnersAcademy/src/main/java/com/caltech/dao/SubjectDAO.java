package com.caltech.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.caltech.dbconfig.DbUtil;
import com.caltech.pojo.Subjects;
import com.caltech.pojo.Teacher;

public class SubjectDAO {

	public List<Subjects> display() throws ClassNotFoundException, SQLException {
		DbUtil dbutil = new DbUtil();
		Session session = dbutil.dbConn();
		System.out.println(session);
		Transaction tran = session.beginTransaction();
		System.out.println(tran);
		if (session != null)
			System.out.println("db configurations are done");
		else
			System.out.println("connection with db failed");

		Query q = session.createQuery("from Subjects");
		List<Subjects> list = q.list();
		return list;
	}

	public int addsubject(Subjects subject) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {
			Subjects t1 = new Subjects();
			t1.setSuname(subject.getSuname());
			value = (Integer) session.save(t1);
			System.out.println(value);
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}

	public int editsubject(Subjects subject) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {

			Query q = session.createQuery("update Subjects set suname=:name where suid=:id");
			Subjects t1 = new Subjects();
			t1.setSuid(subject.getSuid());
			t1.setSuname(subject.getSuname());
			q.setParameter("name", t1.getSuname());
			q.setParameter("id", t1.getSuid());
			value = q.executeUpdate();
			if (value > 0) {
				System.out.println("updated");
			}
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}

	public int deletesubject(Subjects subject) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {

			Query q = session.createQuery("delete from Subjects where suid=:id");
			Subjects t1 = new Subjects();
			t1.setSuid(subject.getSuid());
			q.setParameter("id", t1.getSuid());
			value = q.executeUpdate();
			System.out.println(value);
			if (value > 0) {
				System.out.println("deleted");
			}
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}
	public List<Subjects> subjectsdropdownpopulate(Subjects subject)throws ClassNotFoundException, SQLException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		List<Subjects> list= new ArrayList<Subjects>();
		try
		{
		Query q = session.createQuery("from Subjects");
		 list= q.list();
		trans.commit();
		session.close();
		}catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while retrieving values");
		}
		return list;
	}
}
