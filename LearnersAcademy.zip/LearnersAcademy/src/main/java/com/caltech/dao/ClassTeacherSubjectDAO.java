package com.caltech.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.caltech.dbconfig.DbUtil;
import com.caltech.pojo.ClassTeacherSubject;
import com.caltech.pojo.Classes;
import com.caltech.pojo.Teacher;

public class ClassTeacherSubjectDAO {
	
	public List<ClassTeacherSubject> display() throws ClassNotFoundException, SQLException {
		DbUtil dbutil = new DbUtil();
		Session session = dbutil.dbConn();
		System.out.println(session);
		Transaction tran = session.beginTransaction();
		System.out.println(tran);
		if (session != null)
			System.out.println("db configurations are done");
		else
			System.out.println("connection with db failed");

		Query q = session.createQuery("from ClassTeacherSubject");
		List<ClassTeacherSubject> list = q.list();
		return list;
	}

	public int addCTS(ClassTeacherSubject cts) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {
			ClassTeacherSubject t1 = new ClassTeacherSubject();
			t1.setClname(cts.getClname());
			t1.setTename(cts.getTename());
			t1.setSubname(cts.getSubname());
			value = (Integer) session.save(t1);
			System.out.println(value);
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}
	
	public int editCTS(ClassTeacherSubject cts) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {
			Query q = session.createQuery("update ClassTeacherSubject set subname=:name,tename=:name1 where ctsid=:id");
			ClassTeacherSubject t1 = new ClassTeacherSubject();
			t1.setCtsid(cts.getCtsid());
			t1.setTename(cts.getTename());
			t1.setSubname(cts.getSubname());
			q.setParameter("name", cts.getSubname());
			q.setParameter("name1", cts.getTename());
			q.setParameter("id", cts.getCtsid());
			value = q.executeUpdate();
			if (value > 0) {
				System.out.println("updated");
			}
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}

	public ClassTeacherSubject getctsname(ClassTeacherSubject cts) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		ClassTeacherSubject c1=new ClassTeacherSubject();
		try {
			Query q1=session.createQuery("from ClassTeacherSubject where ctsid=:id");
			ClassTeacherSubject c2=new ClassTeacherSubject();
			c2.setCtsid(cts.getCtsid());
			q1.setParameter("id",c2.getCtsid());
			c1=(ClassTeacherSubject) q1.uniqueResult();
			System.out.println(c1);
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			c1=null;
		}
		return c1;
	}
	public int deleteCTS(ClassTeacherSubject cts) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {

			Query q = session.createQuery("delete from ClassTeacherSubject where ctsid=:id");
			ClassTeacherSubject t1 = new ClassTeacherSubject();
			t1.setCtsid(cts.getCtsid());
			q.setParameter("id", t1.getCtsid());
			value = q.executeUpdate();
			// System.out.println(value);
			if (value > 0) {
				System.out.println("deleted");
			}
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}
	public List<ClassTeacherSubject> getsubjects(Classes classes) throws ClassNotFoundException, SQLException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		List<ClassTeacherSubject> list;
		try {
			Classes cl=new Classes();
			cl.setCname(classes.getCname());
			Query q = session.createQuery("from ClassTeacherSubject where clname=:name");
			ClassTeacherSubject t1 = new ClassTeacherSubject();
			t1.setClname(cl.getCname());
			q.setParameter("name", t1.getClname());
			list = q.list();
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			list = null;
		}
		
		return list;
	}
}
