package com.caltech.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.caltech.dbconfig.DbUtil;
import com.caltech.pojo.Classes;
import com.caltech.pojo.Student;
import com.caltech.pojo.Teacher;

public class ClassDAO {

	public List<Classes> display() throws ClassNotFoundException, SQLException {
		DbUtil dbutil = new DbUtil();
		Session session = dbutil.dbConn();
		System.out.println(session);
		Transaction tran = session.beginTransaction();
		System.out.println(tran);
		if (session != null) 
			System.out.println("db configurations are done");
		 else 
			System.out.println("connection with db failed");


		Query q = session.createQuery("from Classes");
		List<Classes> list = q.list();
		return list;
	}

	public int addclass(Classes classes) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {
			Classes cl = new Classes();
			cl.setCname(classes.getCname());			
			value = (Integer) session.save(cl);
			System.out.println(value);
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}
	
	public int editclass(Classes classes) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		try {
			
			Query q=session.createQuery("update Classes set cname=:name where cid=:id");
			Classes cl = new Classes();
			cl.setCid(classes.getCid());
			cl.setCname(classes.getCname());
			q.setParameter("name",cl.getCname());
			q.setParameter("id",cl.getCid());
			value= q.executeUpdate();
			//System.out.println(value);
			if(value>0) {
				System.out.println("updated");
			}
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value = 0;
		}
		return value;
	}
	
	public int deleteclass(Classes classes) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		int value = 0;
		int value1 = 0;
		try {
			
			Query q=session.createQuery("delete from Student where cid=:id");
			Student s1 = new Student();
			s1.setClasses(classes);
			q.setParameter("id",s1.getClasses().getCid());
			value= q.executeUpdate();
			
			Query q1=session.createQuery("delete from Classes where cid=:id");
			Classes cl = new Classes();
			cl.setCid(classes.getCid());
			q1.setParameter("id",cl.getCid());	
			value1= q1.executeUpdate();
			//System.out.println(value);
			if(value1>0) {
				System.out.println("deleted");
			}
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			value1 = 0;
		}
		return value1;
	}
	
	public Classes getclassname(Classes classes) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		Classes c1=new Classes();
		try {
			Query q1=session.createQuery("from Classes where cid=:id");
			Classes c2=new Classes();
			c2.setCid(classes.getCid());
			q1.setParameter("id",c2.getCid());
			c1=(Classes) q1.uniqueResult();
			System.out.println(c1);
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			c1=null;
		}
		return c1;
	}
	public List<Classes> Classesdropdownpopulate(Classes cl)throws ClassNotFoundException, SQLException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		List<Classes> list= new ArrayList<Classes>();
		try
		{
		Query q = session.createQuery("from Classes");
		 list= q.list();
		trans.commit();
		session.close();
		}catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while retrieving values");
		}
		return list;
	}

	public Classes getclassobj(String name) throws IOException {
		DbUtil dbconn = new DbUtil();
		Session session = dbconn.dbConn();
		Transaction trans = session.beginTransaction();
		Classes c1=new Classes();
		try {
			Query q1=session.createQuery("from Classes where cname=:name");
			Classes c2=new Classes();
			c2.setCname(name);
			q1.setParameter("name",c2.getCname());
			c1=(Classes) q1.uniqueResult();
			System.out.println(c1);
			trans.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception while inserting values");
			c1=null;
		}
		return c1;
	}
}
